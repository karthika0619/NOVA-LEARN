import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Activity, ArrowRight, BarChart3, BookOpen, Brain, CalendarDays,
  CheckCircle2, ChevronDown, CircleHelp, Clock3, GraduationCap,
  LayoutDashboard, Lightbulb, LogOut, Menu, MessageCircle, Search,
  Settings, ShieldCheck, Sparkles, Target, TrendingUp, Users, X,
  Zap, PlayCircle, Check, Flame, Bell, BookMarked
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip,
  XAxis, YAxis, BarChart, Bar
} from "recharts";

type Page = "Overview" | "My Courses" | "AI Teacher" | "Learning Twin" | "Analytics" | "Instructor" | "Admin";
type Course = { title: string; category: string; progress: number; lessons: string; color: string; icon: string };

const courses: Course[] = [
  { title: "Python for Curious Minds", category: "PROGRAMMING", progress: 50, lessons: "Lesson 2 of 4", color: "violet", icon: "⌘" },
  { title: "Data Storytelling", category: "ANALYTICS", progress: 50, lessons: "Lesson 3 of 6", color: "blue", icon: "▥" },
  { title: "UX Foundations", category: "DESIGN", progress: 33, lessons: "Lesson 1 of 3", color: "orange", icon: "✳" },
];
const studyData = [
  { day: "Mon", minutes: 35 }, { day: "Tue", minutes: 52 }, { day: "Wed", minutes: 26 },
  { day: "Thu", minutes: 64 }, { day: "Fri", minutes: 41 }, { day: "Sat", minutes: 58 }, { day: "Sun", minutes: 30 },
];
const masteryData = [
  { topic: "Charts", mastery: 55 }, { topic: "Storytelling", mastery: 64 },
  { topic: "Variables", mastery: 74 }, { topic: "Loops", mastery: 40 },
];
const navItems: { label: Page; icon: typeof LayoutDashboard; section?: string }[] = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "My Courses", icon: BookOpen },
  { label: "AI Teacher", icon: Sparkles },
  { label: "Learning Twin", icon: Brain },
  { label: "Analytics", icon: BarChart3 },
  { label: "Instructor", icon: GraduationCap, section: "WORKSPACE" },
  { label: "Admin", icon: ShieldCheck },
];

function ProgressBar({ value, color = "purple" }: { value: number; color?: string }) {
  return <div className="progress-track"><div className={`progress-fill ${color}`} style={{ width: `${value}%` }} /></div>;
}

function App() {
  const [page, setPage] = useState<Page>("Overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [search, setSearch] = useState("");
  const [quizAnswer, setQuizAnswer] = useState("");
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<number[]>([1, 2]);
  const [notice, setNotice] = useState("");

  const filteredCourses = useMemo(() => courses.filter((course) =>
    `${course.title} ${course.category}`.toLowerCase().includes(search.toLowerCase())
  ), [search]);

  function choosePage(next: Page) {
    setPage(next);
    setMobileNav(false);
    setNotice("");
  }

  function toggleStep(step: number) {
    setCompletedSteps((current) => current.includes(step) ? current.filter((item) => item !== step) : [...current, step]);
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={22} /></div>
          <div><div className="brand-name">NOVA<span>Learn</span></div><div className="brand-caption">YOUR PERSONAL LEARNING SPACE</div></div>
          <button className="mobile-close icon-button" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18} /></button>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="nav-list">
          {navItems.map(({ label, icon: Icon, section }) => (
            <div key={label}>
              {section && <div className="workspace-label nav-section">{section}</div>}
              <button className={`nav-item ${page === label ? "active" : ""}`} onClick={() => choosePage(label)}>
                <Icon size={18} strokeWidth={1.8} /><span>{label}</span>
                {label === "AI Teacher" && <span className="nav-new">NEW</span>}
              </button>
            </div>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon"><CircleHelp size={18} /></div>
            <div><strong>Need a hand?</strong><p>We're here to help you learn.</p><button onClick={() => setNotice("Help centre: support information can be connected here.")}>Visit help centre <ArrowRight size={13} /></button></div>
          </div>
          <button className="nav-item" onClick={() => setNotice("Settings page is a frontend placeholder.")}><Settings size={18} /><span>Settings</span></button>
          <div className="profile-row">
            <div className="avatar">AS</div><div className="profile-copy"><strong>Aanya Sharma</strong><span>Student account</span></div><button className="icon-button" aria-label="Profile menu" onClick={() => setNotice("Profile menu placeholder.")}><ChevronDown size={16} /></button>
          </div>
        </div>
      </aside>

      {mobileNav && <button className="mobile-overlay" onClick={() => setMobileNav(false)} aria-label="Close navigation" />}
      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu icon-button" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu size={20} /></button>
            <div className="breadcrumb">Workspace <span>/</span> <strong>{page}</strong></div>
          </div>
          <div className="topbar-actions">
            <label className="search-box"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search courses..." /></label>
            <button className="icon-button notification" aria-label="Notifications" onClick={() => setNotice("You're all caught up!")}><Bell size={19} /><i /></button>
            <div className="top-avatar">AS</div>
          </div>
        </header>

        <div className="content">
          {notice && <div className="notice"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={15} /></button></div>}
          {page === "Overview" && <Overview onNavigate={choosePage} filteredCourses={filteredCourses} />}
          {page === "My Courses" && <CoursesPage filteredCourses={filteredCourses} onNavigate={choosePage} />}
          {page === "AI Teacher" && <TeacherPage completedSteps={completedSteps} toggleStep={toggleStep} quizAnswer={quizAnswer} setQuizAnswer={setQuizAnswer} quizSubmitted={quizSubmitted} setQuizSubmitted={setQuizSubmitted} />}
          {page === "Learning Twin" && <TwinPage />}
          {page === "Analytics" && <AnalyticsPage />}
          {page === "Instructor" && <RolePage role="Instructor" />}
          {page === "Admin" && <RolePage role="Administrator" />}
          <footer className="footer"><span>© 2026 NOVA Learn</span><span>Learning that adapts to every student <span className="footer-dot">✦</span></span></footer>
        </div>
      </main>
    </div>
  );
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>;
}

function Overview({ onNavigate, filteredCourses }: { onNavigate: (page: Page) => void; filteredCourses: Course[] }) {
  return <>
    <PageHeading eyebrow="FRIDAY, OCTOBER 16" title={<>Good morning, Aanya <span className="wave">✦</span></>} subtitle="A little progress each day adds up to big results." action={<button className="button button-primary" onClick={() => onNavigate("AI Teacher")}><Sparkles size={16} /> Start today's class</button>} />
    <section className="hero-card">
      <div className="hero-content">
        <div className="hero-pill"><span className="pulse-dot" /> YOUR AI TEACHER IS READY</div>
        <h2>Let's make your next<br /><span>big learning breakthrough.</span></h2>
        <p>Your learning twin spotted an opportunity to improve your understanding of <strong>Loops</strong>. Ready for a guided practice session?</p>
        <button className="button button-light" onClick={() => onNavigate("AI Teacher")}>Continue your class <ArrowRight size={16} /></button>
      </div>
      <div className="hero-art" aria-hidden="true">
        <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
        <div className="planet"><Brain size={54} strokeWidth={1.35} /></div>
        <div className="float-card float-top"><Sparkles size={15} /><span>Personalized for you</span></div>
        <div className="float-card float-bottom"><CheckCircle2 size={17} /><div><strong>Learning twin updated</strong><small>Just now</small></div></div>
        <div className="sparkle sparkle-a">✦</div><div className="sparkle sparkle-b">✧</div>
      </div>
    </section>

    <section className="stats-grid">
      <StatCard icon={<Flame size={18} />} label="Learning streak" value="6 days" foot="You're building a habit!" tone="orange" />
      <StatCard icon={<Brain size={18} />} label="Retention score" value="74%" foot={<><TrendingUp size={13} /> 8% this week</>} tone="purple" />
      <StatCard icon={<Clock3 size={18} />} label="Study time" value="4.5 hrs" foot="This week so far" tone="blue" />
      <StatCard icon={<Target size={18} />} label="Topics mastered" value="12 / 16" foot="4 topics to go" tone="green" />
    </section>

    <div className="section-heading"><div><h2>Pick up where you left off</h2><p>Your courses are right where you need them.</p></div><button className="text-button" onClick={() => onNavigate("My Courses")}>View all courses <ArrowRight size={15} /></button></div>
    <div className="course-grid">
      {filteredCourses.slice(0, 3).map((course) => <CourseCard key={course.title} course={course} onContinue={() => onNavigate("My Courses")} />)}
      {filteredCourses.length === 0 && <div className="empty-state">No courses match your search. Try another keyword.</div>}
    </div>

    <div className="lower-grid">
      <section className="panel study-panel">
        <div className="panel-heading"><div><h3>Your study rhythm</h3><p>Minutes studied · last 7 days</p></div><button className="more-button" onClick={() => onNavigate("Analytics")}>View analytics <ArrowRight size={14} /></button></div>
        <div className="chart-wrap"><ResponsiveContainer width="100%" height={210}><AreaChart data={studyData} margin={{ top: 10, right: 5, left: -20, bottom: 0 }}><defs><linearGradient id="studyGradient" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8270ed" stopOpacity={0.22}/><stop offset="95%" stopColor="#8270ed" stopOpacity={0.01}/></linearGradient></defs><CartesianGrid stroke="#edf0f7" strokeDasharray="4 5" vertical={false}/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#969db0", fontSize: 12 }} dy={10}/><YAxis axisLine={false} tickLine={false} tick={{ fill: "#969db0", fontSize: 11 }} ticks={[0,20,40,60,80]}/><Tooltip contentStyle={{ border: "1px solid #ececf4", borderRadius: 12, boxShadow: "0 8px 25px #1c21420d" }} formatter={(value) => [`${value} min`, "Study time"]}/><Area type="monotone" dataKey="minutes" stroke="#8069e8" strokeWidth={2.5} fill="url(#studyGradient)" activeDot={{ r: 5, strokeWidth: 0 }}/></AreaChart></ResponsiveContainer></div>
      </section>
      <section className="panel teacher-mini">
        <div className="panel-heading"><div><h3>Recommended next step</h3><p>Based on your Learning Twin</p></div><div className="recommend-icon"><Lightbulb size={19} /></div></div>
        <div className="recommend-topic"><div className="topic-icon">{"{ }"}</div><div><span className="topic-tag">PROGRAMMING</span><strong>Practice Loops</strong><small>Build confidence one step at a time.</small></div></div>
        <div className="recommend-progress"><div><span>Current mastery</span><strong>40%</strong></div><ProgressBar value={40} color="orange" /></div>
        <button className="button button-outline full-button" onClick={() => onNavigate("AI Teacher")}>Start 10-minute drill <ArrowRight size={15} /></button>
      </section>
    </div>
  </>;
}

function StatCard({ icon, label, value, foot, tone }: { icon: React.ReactNode; label: string; value: string; foot: React.ReactNode; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-foot">{foot}</div></div>;
}

function CourseCard({ course, onContinue }: { course: Course; onContinue: () => void }) {
  return <article className="course-card">
    <div className={`course-art ${course.color}`}><div className="course-symbol">{course.icon}</div><span>{course.category}</span><div className="art-orb" /></div>
    <div className="course-card-body"><div className="course-title-row"><h3>{course.title}</h3><button className="icon-button small-icon" onClick={onContinue} aria-label={`Open ${course.title}`}><ArrowRight size={16}/></button></div><div className="course-meta"><span><BookMarked size={13}/>{course.lessons}</span><strong>{course.progress}%</strong></div><ProgressBar value={course.progress} color={course.color === "orange" ? "orange" : course.color === "blue" ? "blue" : "purple"}/><button className="course-link" onClick={onContinue}>Continue learning <ArrowRight size={14}/></button></div>
  </article>;
}

function CoursesPage({ filteredCourses, onNavigate }: { filteredCourses: Course[]; onNavigate: (page: Page) => void }) {
  return <>
    <PageHeading eyebrow="YOUR LEARNING LIBRARY" title="My courses" subtitle="Keep going. Every lesson brings you one step closer." action={<button className="button button-primary" onClick={() => onNavigate("AI Teacher")}><Sparkles size={16}/> Ask AI Teacher</button>} />
    <div className="course-filter-row"><div className="filter-chip selected">All courses <span>{filteredCourses.length}</span></div><div className="filter-chip">In progress</div><div className="filter-chip">Completed</div></div>
    <div className="course-grid course-grid-page">{filteredCourses.map((course) => <CourseCard key={course.title} course={course} onContinue={() => onNavigate("AI Teacher")}/>)}</div>
    <section className="panel courses-tip"><div className="tip-icon"><Lightbulb size={21}/></div><div><h3>Learning tip</h3><p>Short, consistent study sessions can help you build a stronger learning habit. Try a 10-minute practice session today.</p></div></section>
  </>;
}

function TeacherPage({ completedSteps, toggleStep, quizAnswer, setQuizAnswer, quizSubmitted, setQuizSubmitted }: { completedSteps: number[]; toggleStep: (step: number) => void; quizAnswer: string; setQuizAnswer: (answer: string) => void; quizSubmitted: boolean; setQuizSubmitted: (submitted: boolean) => void }) {
  const steps = [
    { title: "Warm-up: recall", type: "WARM-UP", time: "5 min" },
    { title: "Variables and types", type: "LESSON", time: "11 min" },
    { title: "Loops without the fear", type: "LESSON", time: "14 min" },
    { title: "Checkpoint: Loops", type: "CHECKPOINT", time: "3 min" },
    { title: "Practice challenge", type: "PRACTICE", time: "19 min" },
  ];
  return <>
    <PageHeading eyebrow="YOUR PERSONAL AI TEACHER" title="Today's class" subtitle="A practical session planned around what you need most." action={<div className="duration-pill"><Clock3 size={15}/> About 52 min</div>} />
    <div className="teacher-layout">
      <div className="teacher-main">
        <section className="teacher-note"><div className="note-icon"><Sparkles size={20}/></div><div><span className="note-label">YOUR TEACHER'S NOTE</span><h3>Let's get comfortable with Loops.</h3><p>Your current mastery is 40%, making Loops your best opportunity for growth. We'll keep the lessons in order and give the checkpoint extra attention.</p></div></section>
        <section className="panel lesson-panel"><div className="panel-heading"><div><h3>Your learning path</h3><p>{completedSteps.length} of {steps.length} steps completed</p></div><div className="step-counter">{Math.round(completedSteps.length / steps.length * 100)}%</div></div><ProgressBar value={completedSteps.length / steps.length * 100}/><div className="lesson-list">{steps.map((step, index) => { const number = index + 1; const done = completedSteps.includes(number); return <div className={`lesson-step ${done ? "done" : ""}`} key={step.title}><button className="step-check" onClick={() => toggleStep(number)} aria-label={`${done ? "Mark incomplete" : "Mark complete"}: ${step.title}`}>{done ? <Check size={15}/> : number}</button><div className="lesson-step-copy"><span className="step-type">{step.type}</span><strong>{step.title}</strong></div><span className="step-time"><Clock3 size={13}/>{step.time}</span><button className="step-action" onClick={() => toggleStep(number)}>{done ? "Completed" : "Mark done"}</button></div>; })}</div></section>
      </div>
      <aside className="teacher-side">
        <section className="panel checkpoint-panel"><div className="checkpoint-top"><div className="checkpoint-icon"><Target size={19}/></div><span>QUICK CHECKPOINT</span></div><h3>Which statement best describes a loop in programming?</h3><p>Choose one answer to check your understanding.</p><div className="answer-list">{["A way to repeat a block of code", "A place to store a number", "A tool for drawing charts", "A type of computer hardware"].map((answer, i) => { const correct = answer.startsWith("A way"); const selected = quizAnswer === answer; return <button key={answer} className={`answer-option ${selected ? "selected" : ""} ${quizSubmitted && correct ? "correct" : ""} ${quizSubmitted && selected && !correct ? "incorrect" : ""}`} onClick={() => { setQuizAnswer(answer); setQuizSubmitted(false); }}><span className="answer-letter">{String.fromCharCode(65+i)}</span><span>{answer}</span>{quizSubmitted && correct && <CheckCircle2 size={17}/>}</button>; })}</div>{quizSubmitted && <div className={`quiz-feedback ${quizAnswer.startsWith("A way") ? "right" : "wrong"}`}>{quizAnswer.startsWith("A way") ? "That's right! Loops repeat instructions while a condition or sequence allows them to continue." : "Not quite. A loop repeats a block of code. Give it another try in your next practice session."}</div>}<button className="button button-primary full-button" disabled={!quizAnswer} onClick={() => setQuizSubmitted(true)}>Check answer <ArrowRight size={15}/></button><div className="secure-note"><ShieldCheck size={14}/> Demo interaction · connect to the backend for real scoring</div></section>
        <section className="mini-twin"><div className="mini-twin-head"><Brain size={18}/><strong>Your Learning Twin</strong></div><div className="mini-twin-row"><span>Loops mastery</span><strong>40%</strong></div><ProgressBar value={40} color="orange"/><button className="text-button" onClick={() => window.dispatchEvent(new CustomEvent("nova-navigate-twin"))}>View learning profile <ArrowRight size={14}/></button></section>
      </aside>
    </div>
  </>;
}

function TwinPage() {
  return <>
    <PageHeading eyebrow="YOUR PERSONAL LEARNING PROFILE" title="Your Learning Twin" subtitle="A snapshot of how you're progressing across topics." action={<div className="duration-pill"><Activity size={15}/> Sample profile</div>} />
    <section className="twin-summary"><div className="twin-brain"><Brain size={35}/></div><div><span className="eyebrow">OVERALL LEARNING PICTURE</span><h2>You're building momentum.</h2><p>Your profile highlights topics to review and areas where you're ready for a challenge.</p></div><div className="twin-score"><strong>74%</strong><span>Retention score</span></div></section>
    <div className="twin-content-grid"><section className="panel"><div className="panel-heading"><div><h3>Mastery by topic</h3><p>Use this view to spot your next learning opportunity.</p></div></div><div className="mastery-list">{masteryData.map((item) => <div className="mastery-row" key={item.topic}><div className="mastery-label"><span>{item.topic}</span><strong>{item.mastery}%</strong></div><ProgressBar value={item.mastery} color={item.mastery < 50 ? "orange" : "purple"}/></div>)}</div></section>
      <section className="panel"><div className="panel-heading"><div><h3>Your learning signals</h3><p>Profile indicators</p></div></div><div className="signal-list"><Signal icon={<Brain size={17}/>} label="Retention" value="74%" detail="Remembering recent material" color="purple"/><Signal icon={<Target size={17}/>} label="Focus" value="Good" detail="Steady learning sessions" color="blue"/><Signal icon={<Zap size={17}/>} label="Pace" value="Steady" detail="Consistent progress" color="orange"/></div></section></div>
    <section className="panel next-steps-panel"><div className="panel-heading"><div><h3>Next best steps</h3><p>Suggested activities based on the sample profile.</p></div><Lightbulb className="purple-text" size={20}/></div><div className="next-step-row"><div className="next-step-icon orange-bg"><Target size={18}/></div><div><strong>Review Loops with a 10-minute drill</strong><p>Strengthen the topic with the lowest current mastery.</p></div><span className="priority-tag">HIGH PRIORITY</span></div><div className="next-step-row"><div className="next-step-icon blue-bg"><TrendingUp size={18}/></div><div><strong>Push Charts to mastery with a stretch quiz</strong><p>Build on your existing understanding of data visualization.</p></div><span className="priority-tag normal">NEXT UP</span></div></section>
    <p className="sample-disclaimer">Note: All values shown are sample data for the frontend demonstration.</p>
  </>;
}

function Signal({ icon, label, value, detail, color }: { icon: React.ReactNode; label: string; value: string; detail: string; color: string }) {
  return <div className="signal-row"><div className={`signal-icon ${color}`}>{icon}</div><div className="signal-copy"><strong>{label}</strong><span>{detail}</span></div><b>{value}</b></div>;
}

function AnalyticsPage() {
  return <>
    <PageHeading eyebrow="YOUR PROGRESS AT A GLANCE" title="Learning analytics" subtitle="Small steps, visible progress. See your study rhythm over time." action={<div className="duration-pill"><CalendarDays size={15}/> Last 7 days</div>} />
    <div className="analytics-stats"><StatCard icon={<Clock3 size={18}/>} label="Total study time" value="4h 26m" foot="Across 7 days" tone="blue"/><StatCard icon={<TrendingUp size={18}/>} label="Average per day" value="38 min" foot="Keep your rhythm going" tone="purple"/><StatCard icon={<Target size={18}/>} label="Top mastery" value="74%" foot="Variables" tone="green"/></div>
    <section className="panel analytics-chart"><div className="panel-heading"><div><h3>Minutes studied</h3><p>Daily study time for the last 7 days</p></div><span className="chart-legend"><i className="legend-purple"/> Study minutes</span></div><ResponsiveContainer width="100%" height={290}><AreaChart data={studyData} margin={{ top: 15, right: 20, left: 0, bottom: 0 }}><defs><linearGradient id="studyGradientLarge" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8270ed" stopOpacity={0.22}/><stop offset="95%" stopColor="#8270ed" stopOpacity={0.01}/></linearGradient></defs><CartesianGrid stroke="#edf0f7" strokeDasharray="4 5" vertical={false}/><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#969db0", fontSize: 12 }} dy={10}/><YAxis axisLine={false} tickLine={false} tick={{ fill: "#969db0", fontSize: 12 }} ticks={[0,20,40,60,80]}/><Tooltip formatter={(value) => [`${value} min`, "Study time"]}/><Area type="monotone" dataKey="minutes" stroke="#8069e8" strokeWidth={3} fill="url(#studyGradientLarge)"/></AreaChart></ResponsiveContainer></section>
    <section className="panel analytics-chart"><div className="panel-heading"><div><h3>Mastery by topic</h3><p>Current sample mastery scores</p></div></div><ResponsiveContainer width="100%" height={260}><BarChart data={masteryData} margin={{ top: 15, right: 20, left: 0, bottom: 0 }}><CartesianGrid stroke="#edf0f7" strokeDasharray="4 5" vertical={false}/><XAxis dataKey="topic" axisLine={false} tickLine={false} tick={{ fill: "#7e859a", fontSize: 12 }} dy={10}/><YAxis domain={[0,100]} axisLine={false} tickLine={false} tick={{ fill: "#969db0", fontSize: 12 }} ticks={[0,20,40,60,80,100]}/><Tooltip formatter={(value) => [`${value}%`, "Mastery"]}/><Bar dataKey="mastery" fill="#8875ee" radius={[7,7,0,0]} maxBarSize={48}/></BarChart></ResponsiveContainer></section>
    <p className="sample-disclaimer">Charts use sample data. Connect the backend to display each student's saved study sessions and Learning Twin values.</p>
  </>;
}

function RolePage({ role }: { role: "Instructor" | "Administrator" }) {
  const isInstructor = role === "Instructor";
  return <>
    <PageHeading eyebrow="WORKSPACE TOOLS" title={isInstructor ? "Instructor workspace" : "Platform administration"} subtitle={isInstructor ? "Create courses and understand how learners are progressing." : "A high-level view of users, courses, and platform activity."} action={<div className="duration-pill"><ShieldCheck size={15}/> Demo view</div>} />
    <div className="analytics-stats">{(isInstructor ? [{ label: "Published courses", value: "8", foot: "Across your workspace", tone: "purple" }, { label: "Active learners", value: "124", foot: "Sample count", tone: "blue" }, { label: "Average progress", value: "68%", foot: "Across courses", tone: "green" }] : [{ label: "Total students", value: "1,248", foot: "Sample platform total", tone: "purple" }, { label: "Instructors", value: "36", foot: "Sample platform total", tone: "blue" }, { label: "Courses", value: "84", foot: "Sample platform total", tone: "green" }]).map((s) => <StatCard key={s.label} icon={isInstructor ? <GraduationCap size={18}/> : <Users size={18}/>} label={s.label} value={s.value} foot={s.foot} tone={s.tone}/>)}</div>
    <section className="panel role-table-panel"><div className="panel-heading"><div><h3>{isInstructor ? "Course performance" : "Platform overview"}</h3><p>{isInstructor ? "Sample course-level progress and quiz performance." : "Example records for the administration interface."}</p></div><button className="button button-outline" onClick={() => alert("Connect this action to the backend to manage real records.")}>{isInstructor ? "Create course" : "Manage users"} <ArrowRight size={14}/></button></div>
      <div className="table-scroll"><table><thead><tr>{(isInstructor ? ["Course", "Learners", "Average progress", "Status"] : ["User / item", "Category", "Activity", "Status"]).map((head) => <th key={head}>{head}</th>)}</tr></thead><tbody>{(isInstructor ? [["Python for Curious Minds", "42 learners", "72%", "Published"], ["Data Storytelling", "51 learners", "68%", "Published"], ["UX Foundations", "31 learners", "54%", "Draft"]] : [["Aanya Sharma", "Student", "Recently active", "Active"], ["Course catalogue", "Content", "84 courses", "Available"], ["Monthly enrollments", "Analytics", "View trend", "Updated"]]).map((row) => <tr key={row[0]}>{row.map((cell, i) => <td key={cell}>{i === 3 ? <span className={`status-pill ${cell === "Draft" ? "draft" : ""}`}>{cell}</span> : cell}</td>)}</tr>)}</tbody></table></div>
    </section>
    <div className="role-note"><ShieldCheck size={18}/><p><strong>Access control note:</strong> This is a frontend demonstration using sample records. Connect authentication and role-based authorization on the backend before using real student or platform data.</p></div>
  </>;
}

export default function AppWithTwinNav() {
  return <AppWithTwinNavInner />;
}
function AppWithTwinNavInner() {
  const [dummy, setDummy] = useState(0);
  // Keep the app entrypoint explicit and make the Learning Twin shortcut work without a routing library.
  useMemo(() => {
    const listener = () => setDummy((n) => n + 1);
    window.addEventListener("nova-navigate-twin", listener);
    return () => window.removeEventListener("nova-navigate-twin", listener);
  }, []);
  return <App key={dummy} />;
}